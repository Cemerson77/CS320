package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import Main.Contact;
import Main.ContactService;

class ContactServiceTest {
	private static ContactService contactService;

	@Test
	    void testGetContactAndUpdateSuccess() {
		    Contact contact1 = new Contact("123456", "Christine", "Emerson", "6038038231", "139 Chestnut St.");
		        
	        assertTrue(contactService.AddContact(contact1));
	        Contact updateContact = contactService.getContact(contact1.getContactId());
	
		        
		    //validating assertions are true for values assigned 
		    assertTrue(contact1.getContactId().equals("123456"));
		    assertTrue(contact1.getFirstName().equals("Christine"));
		    assertTrue(contact1.getLastName().equals("Emerson"));
		    assertTrue(contact1.getPhoneNum().equals("6038038231"));
		    assertTrue(contact1.getAddress().equals("139 Chestnut St."));
		    
		    // testing for update contact
		    //removeContact updateContact = contactService.getContact(addContact.getContactId());	      
		    //assertTrue(contactService.setContactId().equals("123456"));
		    //first name
		    updateContact.setFirstName("Chrissi");
		    updateContact = contactService.getContact(updateContact.getContactId());
		    assertTrue(updateContact.getFirstName().equals("Chrissi"));
		    //last name
		    updateContact.setLastName("Emery");
		    updateContact = contactService.getContact(updateContact.getContactId());
		    assertTrue(updateContact.getLastName().equals("Emery"));
		    //phone number
		    updateContact.setPhoneNum("9421231234");
		    updateContact = contactService.getContact(updateContact.getContactId());
		    assertTrue(updateContact.getPhoneNum().equals("9421231234"));
		    //address
		    updateContact.setAddress("129 Chestnut St.");
		    updateContact = contactService.getContact(updateContact.getContactId());
		    assertTrue(updateContact.getAddress().equals("129 Chestnut St."));
				
		}
	  @Test
		void testDeleteContact(){
          Contact contact1 = new Contact("123456", "Christine", "Emerson", "6038038231", "139 Chestnut St.");
          Contact contact2 = new Contact("123457", "Chrissi", "Emery", "6038038232", "129 Chestnut St.");
        
          assertTrue(contactService.AddContact(contact1));
          assertTrue(contactService.AddContact(contact2));

          contactService.DeleteContact(contactService.getContact(contact1.getContactId()));
        	
          assertTrue(contactService.getContact(contact1.getContactId()) == null);
          assertTrue(contactService.getContact(contact2.getContactId()).equals(contact2));
      	
      }

}
