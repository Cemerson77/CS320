/*
 * Contact service requirements:
 * The contact service shall be able to add contacts with a unique ID.
 * The contact service shall be able to delete contacts per contact ID.
 * The contact service shall be able to update contact fields per contact ID. The following fields are 
 * updatable:
 * firstName
 * lastName
 * Number
 * Address
 */

package Main;

import java.util.ArrayList;
import java.util.Random;

public class ContactService {

	private ArrayList<Contact> contactList = new ArrayList<Contact>();
	private int contactCount = 0;
	
	public int getContactCount() {
		return contactCount;
	}

	public ArrayList<Contact> getContactList(){
		return contactList;
	}
	
    public boolean AddContact(Contact contact) {
    	boolean isSuccess = false;
    	
    	if(!contactList.contains(contact.getContactId())) {
    		contactList.add(contact);
    		contactCount++;
    		isSuccess = true;
    	}
    	return isSuccess;
    }
	
    public boolean DeleteContact(Contact contact) {
    	boolean isSuccess = false;
    	
    	if(contactList.contains(contact.getContactId())){
    		contactList.remove(contact);
    		contactCount--;
    		isSuccess = true;
    	}
    	return isSuccess;
    }
    
    //Method to receive the contactId and return the contact object
    public Contact getContact(String contactId){
    	for (Contact c : contactList) {
			while (c.getContactId() == contactId) {
          		return c;
        	}
        }
		return null;
    }
    

	//Method for updating contact WRONG
	public void UpdateContact(String contractId, String update, int selection) {
		if(contractId == null || contractId.length() > 10 || update == null || selection < 0) {
			throw new IllegalArgumentException("Invalid contractId");
		}
		
		if(contactList.isEmpty()) {
			throw new IllegalArgumentException("No contacts exist in list");
		}
		
		int index = -1;
		for (Contact c : contactList) {
			if (c.getContactId() == contractId) {
				index = contactList.indexOf(c);
			}
			
		}
		if (index == -1) {
			System.out.println("Contact not found.");
			return;
		}
		
		Contact updateContact = contactList.get(index);
		
		switch (selection){
		case 1:{
			updateContact.setFirstName(update);
			break;
		}
		case 2:{
			updateContact.setLastName(update);
			break;
		}
		case 3:{
			updateContact.setPhoneNum(update);
			break;
		}
		case 4:{
			updateContact.setAddress(update);
			break;
		}
		default:{
			System.out.println("Contact not updated, invalid change requested.");
			break;
		}
		}
		
		DeleteContact(contactList.remove(index));
		AddContact(updateContact);
				
	}
	
	//Method for generating a unique id for contactId
	public String GenerateUniqueID() {
		// auto generate a random ID for contact
		Random random = new Random();
		int newID = random.nextInt(1000000000);
		String uniqueID = Integer.toString(newID);
		
		for (Contact c : contactList) {
			while (c.getContactId() == uniqueID) {
				newID = random.nextInt(1000000000);
				uniqueID = Integer.toString(newID);
			}
			
		}
		
		System.out.println("ID created: " + uniqueID);
		return uniqueID;
	}
	
	
	
}
	
