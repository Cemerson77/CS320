/*
 * The task service shall be able to add tasks with a unique ID.
 * The task service shall be able to delete tasks per task ID.
 * The task service shall be able to update task fields per task ID. The following fields are updatable:
 * Name
 * Description
 */
package Main;

import java.util.HashMap;

public class TaskService {
	
	// maps taskID to Task object
	private static TaskService reference = new TaskService();
	
	private static HashMap<String, Task> taskMap;
	
	private TaskService() {
		TaskService.taskMap = new HashMap<String, Task>();
	}
	
	public Task getTask(String taskId) {
		if(!taskMap.containsKey(taskId)) {
			throw new IllegalArgumentException("Task ID not found");
		}
		return taskMap.get(taskId);
	}
	//Create a singleton Task Service
	public static TaskService getService() {
		return reference;
	}
	//add new task
	public static boolean addTask(Task task) {
		if(taskMap.containsKey(task.getTaskId()))
			throw new IllegalArgumentException("Task ID already exists.");
			taskMap.put(task.getTaskId(), task);
		return true;
	}
	//delete contact
	public void deleteTask(String taskId) {
		if (taskMap.containsKey(taskId)) {
			taskMap.remove(taskId);
		}
	}
	//update info
	public void updatesTask(String taskId, String taskName, String taskDescription) {
		
		// gets the task from the Map
		Task task = taskMap.get(taskId);
		
		//checks if contact id exists
		if (!taskMap.containsKey(taskId)) {
			throw new IllegalArgumentException("TaskId" + taskId + "does not exists");
		}

		
		if (taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid task Name");
		}

		task.setTaskName(taskName);

		if (taskDescription == null || taskDescription.length() > 50) {
			throw new IllegalArgumentException("Invalid task description");
		}

		task.setTaskDescription(taskDescription);
	}
	
}
